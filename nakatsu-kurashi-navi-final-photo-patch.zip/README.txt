中津くらしナビ 最終トップ画像パッチ

このパッチは、現在の元サイトにある店舗データ・検索・お気に入り・現在地・観光・ランキング等を残したまま、
トップの中津城イラストだけを写真へ変更します。

【GitHubへ追加するファイル】
1. nakatsu-castle-hero.jpg
2. hero-photo.css

どちらも index.html と同じ場所（リポジトリの一番上）にアップロードしてください。

【index.html に追加する1行】
<head> 内の </head> の直前へ、次を貼り付けます。

<link rel="stylesheet" href="hero-photo.css?v=1">

保存後、公開サイトを再読み込みしてください。
反映されない場合はURL末尾に ?v=2 を付けて開いてください。

公開URL:
https://kaito2343-1.github.io/nakatsu-kurashi-navi/
